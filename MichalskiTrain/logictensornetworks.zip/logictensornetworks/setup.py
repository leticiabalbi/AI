from setuptools import setup

setup(
    name='logictensornetworks',
    version='0.1',
    description='Logic Tensor Networks in Tensorflow 2',
    install_requires=[
        'tensorflow>=2.2.0'
    ]
)