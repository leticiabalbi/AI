from logictensornetworks import fuzzy_ops
from logictensornetworks import utils
from logictensornetworks.core import (Predicate, Function, variable, constant, proposition,
        diag, undiag, Wrapper_Connective, Wrapper_Quantifier)

